const successMessageFunction = (statusValue,dataValue,) => {
    return {
        status: statusValue,
        data: dataValue
    };
};
module.exports = successMessageFunction